package integration.thirdparty.midtrans;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataUtil;
// --- <<IS-END-IMPORTS>> ---

public final class js

{
	// ---( internal utility methods )---

	final static js _instance = new js();

	static js _newInstance() { return new js(); }

	static js _cast(Object o) { return (js)o; }

	// ---( server methods )---




	public static final void generateOrderId (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(generateOrderId)>> ---
		// @sigtype java 3.5
		// [o] field:0:required order_id
		// Start logic
		String prefix = "WEBMETHODS-";
		
		// Get current datetime in format yyyyMMdd-HHmmss
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd-HHmmss");
		String timestamp = sdf.format(new Date());
		
		// Generate random 4-digit number (1000\u20139999)
		Random rand = new Random();
		int randomNum = 1000 + rand.nextInt(9000);
		
		// Combine all parts
		String orderId = prefix + timestamp + "-" + randomNum;
		
		// Output to pipeline
		IDataCursor cursor = pipeline.getCursor();
		IDataUtil.put(cursor, "order_id", orderId);
		cursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void parsePayloadAmounts (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(parsePayloadAmounts)>> ---
		// @sigtype java 3.5
		// [i] field:0:required grossAmount
		// [i] record:1:required itemDetails
		// [o] field:0:required grossAmountInt
		// [o] record:1:required itemDetails
		IDataCursor cursor = pipeline.getCursor();
		try {
		    // 1. Convert grossAmount
		    String grossAmount = IDataUtil.getString(cursor, "grossAmount");
		    if (grossAmount != null && !grossAmount.isEmpty()) {
		        int grossAmountInt = (int) Double.parseDouble(grossAmount);
		        IDataUtil.put(cursor, "grossAmountInt", grossAmountInt);
		    }
		
		    // 2. Convert item_details[] (Document List) price & quantity
		    IData[] itemDetails = IDataUtil.getIDataArray(cursor, "itemDetails");
		    if (itemDetails != null) {
		        for (int i = 0; i < itemDetails.length; i++) {
		            IData item = itemDetails[i];
		            IDataCursor itemCursor = item.getCursor();
		
		            // Convert price
		            String priceStr = IDataUtil.getString(itemCursor, "price");
		            if (priceStr != null && !priceStr.isEmpty()) {
		                int priceInt = (int) Double.parseDouble(priceStr);
		                IDataUtil.put(itemCursor, "price", priceInt); // overwrite
		            }
		
		            // Convert quantity
		            String qtyStr = IDataUtil.getString(itemCursor, "quantity");
		            if (qtyStr != null && !qtyStr.isEmpty()) {
		                int qtyInt = (int) Double.parseDouble(qtyStr);
		                IDataUtil.put(itemCursor, "quantity", qtyInt); // overwrite
		            }
		
		            itemCursor.destroy();
		        }
		
		        // Optional: set item_details[] back to pipeline (not mandatory)
		        IDataUtil.put(cursor, "itemDetails", itemDetails);
		    }
		
		} catch (Exception e) {
		    IDataUtil.put(cursor, "error", "Invalid number format: " + e.getMessage());
		} finally {
		    cursor.destroy();
		}
		// --- <<IS-END>> ---

                
	}
}

